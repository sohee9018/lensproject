package min.spring.lens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LensApplication {

	public static void main(String[] args) {
		SpringApplication.run(LensApplication.class, args);
	}

}
